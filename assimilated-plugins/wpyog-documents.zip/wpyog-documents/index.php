<?php
/*
Plugin Name: WPYog Documents
Description: WPYog Documents.
Author: WPYog
Author URI:http://wpyog.com/
Version: 1.0
License:           	GPLv2 or later
License URI: 		http://www.gnu.org/licenses/gpl-2.0.html
*/
add_action('init', 'wpyog_research_education',1);
function wpyog_research_education() {	
	global $wpdb;
	require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
	$table_categories = $wpdb->prefix . "wpyog_categories"; 
	$charset_collate = $wpdb->get_charset_collate();
	$sqlCategory = "CREATE TABLE IF NOT EXISTS $table_categories (
		`id` BIGINT(20) NOT NULL AUTO_INCREMENT , 
		`cat_name` TEXT NOT NULL , 
		`cat_desc` MEDIUMTEXT NULL , 
		`status` TINYINT(2) NULL DEFAULT '1' , 
		`created` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP , 
		PRIMARY KEY (`id`)
	) $charset_collate;";
	
	
	$table_documents = $wpdb->prefix . "wpyog_documents"; 
	$charset_collate = $wpdb->get_charset_collate();
	$sqlReserchDocuments = "CREATE TABLE IF NOT EXISTS $table_documents (
		`id` BIGINT(20) NOT NULL AUTO_INCREMENT ,
		`category_id` BIGINT(20) NULL,
		`title` TEXT NOT NULL , 
		`description` TEXT NULL ,
		`document_type` VARCHAR(100) NULL,
		`document_link` VARCHAR(250) NULL,
		`media_file` VARCHAR(255) NULL,
		`status` TINYINT(4) NULL DEFAULT '1',			
		`created` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP , 
		PRIMARY KEY (`id`)
	) $charset_collate;";
	
	dbDelta($sqlCategory);
	dbDelta($sqlReserchDocuments);	
	define( 'WPYOG_RESEARCH_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
}
add_action('admin_menu', 'wpyog_research_plugin_menu');

function wpyog_research_plugin_menu(){
	add_menu_page('WPYog Document', 'WPYog Documents', '10', 'wpyog_document','wpyog_document','dashicons-wpyog-icon','120');
	
	add_submenu_page( 'wpyog_document', 'WPYog Research Document', 'All Documents', 'manage_options', 'wpyog_all_document', 'wpyog_all_document');
	
	add_submenu_page('wpyog_document','Add New','Add New Document','0','wpyog_add_new_document','wpyog_add_new_document');
	
	add_submenu_page(null,'Delete Research','Delete Topic','0','wpyog_delete_research','wpyog_delete_research');
	add_submenu_page(null, 'Document status', 'Document status', 'manage_options', 'wpyog_changes_document_status', 'wpyog_changes_document_status'); 
	add_action( 'admin_enqueue_scripts', 'wpyog_document_admin_script' );	
}
function wpyog_document_admin_script(){
	global $post;
	wp_register_style( 'wpyog_document_admin_css', plugin_dir_url( __FILE__ ). 'wp-research/css/wpyog-document.css', false, '1.0.0' );
	wp_enqueue_style( 'wpyog_document_admin_css' );
	
	wp_register_script( 'wpyog_document_admin_validate', plugin_dir_url( __FILE__ ). 'js/jquery.validate.min.js', false, '1.0.0' );
	wp_enqueue_script( 'wpyog_document_admin_validate' );
	
	wp_register_script( 'wpyog_document_admin_document_js', plugin_dir_url( __FILE__ ). 'js/document-js.js', false, '1.0.0' );
	wp_enqueue_script( 'wpyog_document_admin_document_js' );
	
	wp_enqueue_script('media-upload');
	
	if(is_object($post) ){
		wp_enqueue_media(array('post' => $post->ID));
	}else{
		wp_enqueue_media();
	}
	
}
function wpyog_document(){
	$includeFile = plugin_dir_path( __FILE__ ).'views/index.php';
	include( $includeFile );
}
function wpyog_all_document(){
	global $wpdb;
	
	$pagenum = isset( $_GET['pagenum'] ) ? absint( $_GET['pagenum'] ) : 1;	
	$table_name = $wpdb->prefix . "wpyog_documents";
	
	$limit = 10; // number of rows in page
	$offset = ( $pagenum - 1 ) * $limit;
	$total = $wpdb->get_var( "SELECT COUNT(`id`) FROM {$table_name}" );
	$num_of_pages = ceil( $total / $limit );
	
	$sql = "SELECT wd.*,wc.cat_name from $table_name wd left join {$wpdb->prefix}wpyog_categories wc on wd.category_id = wc.id order by wd.id desc LIMIT {$offset} , {$limit}";
	$rows = $wpdb->get_results($sql, OBJECT);

	$includeFile = plugin_dir_path( __FILE__ ).'views/document-list.php';
	include( $includeFile );
}
function wpyog_add_new_document(){
	global  $wpdb;
	$tableCategory = $wpdb->prefix . "wpyog_categories";
	$categoryList = $wpdb->get_results("SELECT * from $tableCategory where status = 1 order by id desc");
	$tableDocument = $wpdb->prefix . "wpyog_documents";
	$id = sanitize_text_field($_GET['id']);
	if(!empty($id)){
		$documentRow = $wpdb->get_row($wpdb->prepare("SELECT * FROM $tableDocument WHERE id = %d",$id));
	} 
	$includeFile = WPYOG_RESEARCH_PLUGIN_DIR.'views/add_document.php';
	include( $includeFile );
}
add_action('admin_post_add_research_document', 'wpyog_handle_save_research_document');
function wpyog_handle_save_research_document(){
	global  $wpdb;	
    ob_start();
	$id = sanitize_text_field($_POST['id']);	
	if($_POST['action']=='add_research_document'){
		$table_name = $wpdb->prefix . "wpyog_documents";
		/* $category_id = sanitize_text_field($_POST['category_id']); */
		$title = sanitize_text_field(stripslashes(trim($_POST['title'])));
		$description = sanitize_text_field(stripslashes(trim($_POST['description'])));
		$document_type = sanitize_text_field($_POST['document_type']);
		$document_link = sanitize_text_field($_POST['document_link']);
		if(!empty($id)){
			$wpdb->update($table_name,array('title' => $title,'description' => $description,'document_type' => $document_type,'document_link' => $document_link),array('id' => $id));
		}else{
			$wpdb->insert($table_name,array('title' => $title,'description' => $description,'document_type' => $document_type,'document_link' => $document_link));
		}
		$redirectUrl = admin_url('admin.php?page=wpyog_all_document');
		wp_redirect($redirectUrl);
		exit;
	}
}
add_shortcode('wpyog-document-list', 'wpyog_research_document_list' );
function wpyog_research_document_list($atts){
	global $content, $wpdb;
    ob_start();
	extract(shortcode_atts(array(
      'searchOption' => 'top'
	), $atts));
	$tableCategory = $wpdb->prefix . "wpyog_categories";
	$categoryList = $wpdb->get_results("SELECT * from $tableCategory where status = 1");
	
	$table_name = $wpdb->prefix . "wpyog_documents";
	$documentRows = $wpdb->get_results("SELECT wd.*,wc.cat_name from $table_name wd left join {$wpdb->prefix}wpyog_categories wc on wd.category_id = wc.id where wd.status = 1 order by wd.id asc");
	
	$includeFile = plugin_dir_path( __FILE__ ).'views/research-document-list.php';
	include( $includeFile );
	$output = ob_get_clean();
    return $output;
}
function wpyog_statusDocumentMessage($val){
	return ($val==1)?'Enable':'Disable';
}
function wpyog_statDocumentVal($val){
	return ($val==1)?0:1;
}
function wpyog_changes_document_status(){
	ob_start();
	global $wpdb;
	$table_name = $wpdb->prefix . sanitize_text_field($_GET['table']);
	$status = sanitize_text_field($_GET['value']);
	$id = sanitize_text_field($_GET['id']);
	if(!empty($id) && !empty($status)){
		$wpdb->update($table_name,array('status' => $status),array('id' => $id));
	}
	wp_safe_redirect( wp_get_referer() );
	exit;
}
function wpyog_delete_research(){
	ob_start();
	global $wpdb;
	$table_name = $wpdb->prefix . sanitize_text_field($_GET['table']);
	$id = sanitize_text_field($_GET['id']);
	$deleteTopic = "DELETE  FROM $table_name WHERE id = %d";			
	$wpdb->query($wpdb->prepare($deleteTopic,$id));
	wp_safe_redirect( wp_get_referer() );
	exit;
}
add_shortcode('wpyog-document','wpyog_get_wpyog_document');
function wpyog_get_wpyog_document($atts = array()){
	ob_start();
	global $content, $wpdb;
	$document_id = $atts['id'];
	$condition = '';
	$table_name = $wpdb->prefix . "wpyog_documents";	
	if(isset($document_id) && !empty($document_id)) $condition = " AND wd.id = $document_id";	
	$documentRows = $wpdb->get_results("SELECT wd.*,wc.cat_name from $table_name wd left join {$wpdb->prefix}wpyog_categories wc on wd.category_id = wc.id where wd.status = 1 {$condition} order by wd.id asc");
	if(!empty($documentRows)) { 
		$ext = pathinfo($documentRows[0]->document_link, PATHINFO_EXTENSION);
		$iconClass = wpyog_fileExtention($ext);
	?>
	<div class="wpyog-doc-box">
		<div class="wpyog-doc-box-title"><i class="single_doc fa <?php echo $iconClass;?>"></i> <a href="<?php echo $documentRows[0]->document_link;?>" target="_blank"><?php echo $documentRows[0]->title;?></a></div>			
		<?php if(!empty($documentRows[0]->description)){ ?>				
			<div class="wpyog-doc-box-content">	
				<p><?php echo $documentRows[0]->description;?></p>
			</div>
		<?php } ?>		
	</div>
<?php } else { ?>
	<p>[wpyog-document id=<?php echo $document_id;?>]</p>
<?php }
	//echo "<pre>"; print_r($documentRows); exit;
	$output = ob_get_clean();
	$output = wpautop(trim($output));
    return $output;
}
function wpyog_fileExtention($ext){
	switch($ext){
		case 'doc':
		case 'docx':
		    $ext = "fa-file-word-o";
		break;
		case 'pdf':
		    $ext = "fa-file-pdf-o";
		break;
		case 'txt':
		    $ext = "fa-file-text-o";
		break;
		case 'zip':
		case 'rar':
		    $ext = "fa-file-zip-o";
		break;
		case 'ppt':
		case 'pptx':
		    $ext = "fa-file-powerpoint-o";
		break;
		case 'xls':
		case 'csv':
		case 'xlsx':
		    $ext = "fa-file-excel-o";
		break;
		case 'png':
		case 'jpg':
		case 'jpeg':
		case 'gif':
		    $ext = "fa-file-image-o";
		break;
		case 'com':
		    $ext = "fa-globe";
		break;
		default:
			$ext = "fa-file-o";
	}
	return $ext;
}   
add_action('wp_head', 'wpyog_front_scripts');
function wpyog_front_scripts(){	
	wp_register_style( 'wpyog_font_front_css', plugin_dir_url( __FILE__ ). 'wp-research/css/font-awesome.min.css', false, '1.0.0' );
	wp_enqueue_style( 'wpyog_font_front_css' );
	wp_register_style( 'wpyog_document_front_css', plugin_dir_url( __FILE__ ). 'wp-research/css/wpyog_document.min.css', false, '1.0.0' );
	wp_enqueue_style( 'wpyog_document_front_css' );
} 
add_filter('widget_text','do_shortcode');
?>