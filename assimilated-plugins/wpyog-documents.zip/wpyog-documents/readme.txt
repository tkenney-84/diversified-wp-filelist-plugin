=== WPYog Documents ===

Contributors: wpyog
Donate link: http://wpyog.com/
Tags: Document Management, Document, Simple Documents , Topics, PDF document upload, Word document upload
Requires at least: 4.0
Tested up to: 5.6
Stable tag: trunk
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html



== Description ==

A very simple plugin which allows you to upload various files and create document listing
A very simple document plugin that output an unordered document.

* Documents are order by created date. Latest document comes on top.
* Shortcodes: For Full list of document[wpyog-document-list] For single document [wpyog-document id=16] id=“16” is the id of the document, replace with your own document id or copy from “WPYog Document” section.

== Installation ==

1. Download the plugin, and unzip it.
2. Place the wpyog-document folder in your wp-content/plugins folder.
3. Activate the plugin from the plugins tab of your Wordpress admin.
4. Upload documents to "WPYog Document".
5. Place shortcodes [wpyog-document-list] or single document shortcode [wpyog-document id=16]id=“16” is the id of the document, replace with your own document id or copy from “WPYog Document” section.

== Frequently Asked Questions ==

= Can I request a feature to be added on the plugin? =
Certainly and would love to hear about it. 

#### Plugin features:
* Upload any documents like pdf, word etc.
* Display full list of document or single document
* Add / edit listing


== Screenshots ==

1. The WPYog Documents menu.