<div id="grid">	
	<ul>
	<?php foreach($documentRows as $row) {
		$ext = pathinfo($row->document_link, PATHINFO_EXTENSION);
		$iconClass = wpyog_fileExtention($ext);
		?>
		<li class="doc-material fa <?php echo $iconClass;?>">
			 <span class="fileIA"><a class="read-more-link" href="<?php echo $row->document_link;?>" target="_blank"><?php echo $row->title;?></a></span>
		</li>							
	<?php } ?>
	</ul>
</div>

