<div class="wrap">
	<h1 class="wp-heading-inline">&nbsp;</h1>
	<li class="all" style="list-style:none;">
		<a href="javascript:history.go(-1);" class="page-title-action">
			Back
		</a>
	</li>
	<form method="post" id="addDocuments" action="<?php echo get_admin_url();?>admin-post.php" enctype="multipart/form-data">
		<div class="postbox ">
			<h3 class="hndle"><span>Add Document</span></h3>
			
			<div class="inside">
				<!-- Put this in a more decent place when done with styling. -->		
				<div class="post-option">
					<label class="post-option-label">Document Title</label>
					<div class="post-option-value">
						<input type="text" name="title" class="large-text required" id="title" value="<?php echo isset($documentRow->title) ? $documentRow->title : ''; ?>"/>							
					</div>
				</div>
				<div class="post-option">
					<label class="post-option-label">Description (optional)</label>
					<div class="post-option-value">
						<textarea type="text" name="description" class="large-text" id="description"/><?php echo isset($documentRow->description) ? $documentRow->description : ''; ?></textarea>
					</div>
				</div>
				<input type="hidden" name="id" value="<?php echo isset($documentRow->id) ? $documentRow->id : ''; ?>"/>
				
				<?php if(!empty($documentRow->id)) { ?>
					<div class="post-option">
						<label class="post-option-label">Upload Document (required)</label>
						<div class="post-option-value">
							<a href="<?php echo $documentRow->document_link;?>" target="__blank"><?php echo $documentRow->document_link;?></a></span>
							<a href="javascript:void(0);" class="button btn-danger" id="removeDoc">Remove</a>
						</div>
					</div>
				<?php } ?>
				
				<div class="post-option" id="uploadDoc" style="display:<?php echo (!empty($documentRow->id))?'none':'block';?>">
					<label class="post-option-label">Upload Document (required)</label>
					<div class="post-option-value">
						<input type="hidden" name="document_type" value="<?php echo isset($documentRow->document_type) ? $documentRow->document_type : 'document'; ?>" id="document_type">
						<input id="upload-document" type="button" class="button" value="Upload Document" />
						<span id="showLink"></span>
						<input type="hidden" name="document_link" class="large-text required" id="document_link" value="<?php echo isset($documentRow->document_link) ? $documentRow->document_link : ''; ?>"/>
						<label class="error" id="fileError"></label>
					</div>					
				</div>
				<input type='hidden' name='action' value='add_research_document' />
				<div class="post-option">
					<div class="post-option-value">					
						<input type="submit" value="Save" class="button button-primary" id="sub"/>
					</div>
				</div>	
			</div>			
		</div>
	</form>
</div>