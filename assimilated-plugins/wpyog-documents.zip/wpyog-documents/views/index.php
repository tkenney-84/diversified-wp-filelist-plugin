<div class="wrap">
	<hr class="wp-header-end">
	<div class="wpyog-dashboard"style="">
		<img src="<?php echo plugin_dir_url(dirname(__FILE__ ));?>img/wpyog-doc-icon.png" width="140" class="wpyog-image-circle"/>
		<h2>WPYog Document</h2>
		<p>Shortcode for all document [wpyog-document-list]</p>
		<div style="display:inline-block; margin: 0px auto;text-align: center;width:100%;">
		<!-- <a href="<?php echo admin_url('admin.php?page=wpyog_categories'); ?>" class="wpyog_doc_btn">All Categories</a> -->
		<a href="<?php echo admin_url('admin.php?page=wpyog_all_document'); ?>" class="wpyog_doc_btn">All Documents</a>
		</div>
	</div>
</div>