<div class="wrap">
	<h1 class="wp-heading-inline">WPYog Documents</h1>
	<a href="<?php echo admin_url('admin.php?page=wpyog_add_new_document'); ?>" class="page-title-action">Add New</a>
	<div class="wpdocList">Shortcode for all document <strong>[wpyog-document-list]</strong></div>
	<hr class="wp-header-end">
	<div class="table-content">
		<table class='wp-list-table widefat fixed striped posts' id="WPYog_table">
			<thead>
			<tr>
				<th class="manage-column ss-list-width">Title</th>
				<!--<th class="manage-column ss-list-width">Category</th> -->
				<th class="manage-column ss-list-width">Description</th>
				<th class="manage-column ss-list-width">Shortcode</th>
				<th class="manage-column ss-list-width">Status</th>
				<th class="manage-column ss-list-width">Created</th>
				<th>Action</th>
			</tr>
			</thead>
			<tbody>
			<?php $i=1;
			foreach ($rows as $row) { ?>
				<tr>
					<td class="manage-column ss-list-width"><?php echo $row->title; ?></td>
					<!--<td class="manage-column ss-list-width"><?php echo $row->cat_name; ?></td>-->
					<td class="manage-column ss-list-width"><?php echo $row->description; ?></td>
					<td class="manage-column ss-list-width">[wpyog-document id=<?php echo $row->id;?>]</td>
					<td class="manage-column ss-list-width"><a href="<?php echo admin_url('admin.php?page=wpyog_changes_document_status&id=' .  $row->id .'&table=wpyog_documents&value='.wpyog_statDocumentVal($row->status)); ?>"><?php echo wpyog_statusDocumentMessage($row->status);?></a></td>
					<td class="manage-column ss-list-width"><?php echo date('M d, Y h:i A',strtotime($row->created)); ?></td>
					<td>
						<a href="<?php echo admin_url('admin.php?page=wpyog_add_new_document&id=' . $row->id); ?>" class="WPYog-btn-admin WPYog-btn-edit">Edit</a>
						<a href="<?php echo admin_url('admin.php?page=wpyog_delete_research&table=wpyog_documents&id=' . $row->id); ?>" class="WPYog-btn-admin WPYog-btn-delete" onclick="return confirm('Are you sure you want to delete?')">Delete</a>
					</td>
				</tr>
			<?php $i++; } ?>
			</tbody>
		</table>
	</div>
	<?php 
	$page_links = paginate_links( array(
		'base' => add_query_arg( 'pagenum', '%#%' ),
		'format' => '',
		'prev_text' => __( '&laquo;', 'text-domain' ),
		'next_text' => __( '&raquo;', 'text-domain' ),
		'total' => $num_of_pages,
		'current' => $pagenum
	));

	if ($page_links) {
	echo '<div class="tablenav"><div class="tablenav-pages" style="margin: 1em 0">' . $page_links . '</div></div>'; } ?>
</div>